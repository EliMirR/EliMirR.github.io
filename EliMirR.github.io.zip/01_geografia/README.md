# Tema 1: Geografía de República Checa
En esta sección aprenderemos sobre los accidentes geográficos de este emblemático país
## Itinerario
- [Montañas](montana.md)
- [Ríos](rios.md)
- [Ciudades](ciudades.md)
