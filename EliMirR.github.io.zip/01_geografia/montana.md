# Montañas de República Checa

Pese a no tener mucha altitud, este país cuenta con montañas que ofrecen unas vistas espectaculares:

- Montaña Sněžka: Con una altitud de 1,603 metros, esta es la montaña más alta de la República Checa. Se encuentra en la frontera entre la República Checa y Polonia.

- Montaña Černá hora: Ubicada en el Parque Nacional de Krkonoše, esta montaña tiene una altitud de 1,299 metros y es muy popular entre los amantes del esquí.

- Montaña Říp: Con una altitud de 459 metros, Říp es una montaña de fácil acceso y ofrece unas vistas impresionantes de la campiña checa.

