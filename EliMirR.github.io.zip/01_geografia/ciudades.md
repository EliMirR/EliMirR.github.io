# Ciudades de República Checa

Las ciudades de República Checa son ricas en historia y cultura, conservando grandes maravillas arquitectónicas en ellas.


- Praga: La capital del país, conocida como “la ciudad de las cien agujas”, es famosa por su impresionante arquitectura y su casco histórico, declarado Patrimonio de la Humanidad por la UNESCO.

- Brno: La segunda ciudad más grande de la República Checa, se encuentra cerca de Austria y Eslovaquia. Es un importante centro administrativo y educativo.

- Ostrava: La tercera ciudad más poblada del país, juega un papel muy importante en el transporte de mercancías y es el primer centro metalúrgico y minero de la República Checa. 