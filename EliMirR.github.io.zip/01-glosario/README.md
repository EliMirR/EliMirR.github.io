# Bienvenido

En esta sección encontrarás un pequeño glosario con vocabulario checo básico y unos ejercicios