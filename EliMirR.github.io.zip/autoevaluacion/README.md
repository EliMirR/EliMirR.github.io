# Ahoj!
Por aquí dejo la autoevaluación siguiendo la norma UNE 713622020 de Materiales Educativos Digitales (MED) y las conclusiones tras el proyecto.
Muchas gracias por todo.

¡Nos vemos! Uvidíme se později! :)
