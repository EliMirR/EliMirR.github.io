# Bienvenido al curso de cultura checa *Czeck this*

En este curso encontrarás lo necesario para introducirte en la cultura de este maravilloso país. Ya seas un recién llegado a este país o lleves un tiempo, ¡este curso es para ti! Desde temas culturales a aventuras interactivas, aquí tienes todo lo que necesitas saber sobre República Checa.

Para dudas utiliza el siguiente correo de contacto: noesuncorreodeverdad@yahoy.cz


![Meme de Chequia](https://github.com/EliMirR/EliMirR.github.io/blob/main/assests/meme.jpg/index.html)

## Índice

### -[Presentación del curso](https://github.com/EliMirR/EliMirR.github.io/tree/main/04-presentacion/index.html)

### -[Glosario básico](https://github.com/EliMirR/EliMirR.github.io/tree/main/01-glosario/index.html)

### -[Guía vegana por Praga](https://github.com/EliMirR/EliMirR.github.io/tree/main/02-guia/index.html)

### -[Un misterio en la plaza](https://github.com/EliMirR/EliMirR.github.io/tree/main/03-aventura/index.html)

### -[Geografía](https://github.com/EliMirR/EliMirR.github.io/tree/main/01_geografia/index.html)

### -[Historia](https://github.com/EliMirR/EliMirR.github.io/tree/main/02_historia/index.html)

### -[Cultura](https://github.com/EliMirR/EliMirR.github.io/tree/main/03_cultura/index.html)

### -[Autoevaluación y conclusiones](https://github.com/EliMirR/EliMirR.github.io/tree/main/autoevaluacion/index.html)