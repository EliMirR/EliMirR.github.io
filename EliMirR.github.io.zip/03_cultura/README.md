# Tema 3: Cultura de República Checa
En este tema veremos algunos aspectos más relevantes de la cultura checa

## Itinerario
- [Literatura](literatura.md)
- [Música](musica.md)
- [Cine](cine.md)