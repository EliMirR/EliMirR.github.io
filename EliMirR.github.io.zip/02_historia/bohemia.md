# Reino de Bohemia
El Reino de Bohemia fue una monarquía que existió durante la época medieval y la temprana Edad Moderna en Europa Central. Este reino es el predecesor de la moderna República Checa.

El Reino de Bohemia fue un **estado imperial en el Sacro Imperio Romano Germánico** desde 1356, y el rey de Bohemia fue un príncipe elector del imperio. Los reyes de Bohemia, además de la propia región de Bohemia, también gobernaron otras tierras pertenecientes a la Corona de Bohemia, que en varias ocasiones incluyó a Moravia, Silesia, Lusacia y partes de Sajonia, Brandeburgo y Baviera.

El reino fue establecido por **la dinastía de los Premislidas** en el siglo XII a partir del Ducado de Bohemia, y luego fue gobernado por la Casa de Luxemburgo, la dinastía Jagellón, y desde 1526, por la Casa de Habsburgo y su sucesora, la Casa de Habsburgo-Lorena1. Numerosos reyes de Bohemia también fueron elegidos emperadores del Sacro Imperio, y su capital, Praga, fue también la sede imperial a finales del siglo XIV, y nuevamente a finales del siglo XVI y principios del XVII1.

Después de la disolución del Sacro Imperio Romano Germánico en 1806, el territorio pasó a formar parte del Imperio austríaco de los Habsburgo y, posteriormente, del **Imperio austrohúngaro** a partir de 1867, después del Compromiso Austrohúngaro.