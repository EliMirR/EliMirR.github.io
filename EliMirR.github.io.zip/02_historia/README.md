# Tema 2 Historia de República Checa
En este tema veremos un poco de la historia de su país

## Itinerario
- [Reino de Bohemia](bohemia.md)
- [Edad Moderna](moderna.md)
- [Edad Contemporánea](contemporanea.md)